<?php
$server_name="localhost";
$username="root";
$password="";
$database_name="letssave";


if(isset($_POST['save']))
{	end?
	echo " <script>alert('helllo')</script>"
	$conn=mysqli_connect($server_name,$username,$password,$database_name);
	if(!$conn)
	{
		echo " <script>alert('not connected')</script>"
		die("Connection Failed:" . mysqli_connect_error());

	}
	else{
		echo "<script>alert('connected')</script>"  
	}

	 $email = $_POST['email'];
	 $name = $_POST['name'];
	 $address = $_POST['address'];
	 $amount = $_POST['amount']; 
	 $message = $_POST['message'];
     echo "<script>alert('$email')</script>"
	 $sql_query = "INSERT INTO entry_detail (email, name, address, amount, message)
	 VALUES ('$email','$name','$address','$amount','$message')";

	 if (mysqli_query($conn, $sql_query)) 
	 {
		echo "New Details Entry inserted successfully !";
		echo "<script>alert('done')</script>" 
	} 
	else
	{
		echo "Error: " . $sql . "" . mysqli_error($conn);
		echo "<script>alert('failed')</script>" 
	 }
	 mysqli_close($conn);
}
?>

